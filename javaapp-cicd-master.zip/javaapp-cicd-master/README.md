# This is a Demo Project deploying AWS Self Managed Kubernetes Cluster using:
##### 1. Terraform
##### 2. Ansible

### Used GitLab CI/CD to deploy Cluster and deploy application on tiop of the Self Managed Kubernetes Cluster